package com.dicoding.submission.adapter;

import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.dicoding.submission.R;

public class DetailTeamAdapter extends AppCompatActivity {
    private static final String TAG = "DetailTeamAdapter";
    private String title = "Detail Team";

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView((R.layout.item_detail));
        Log.e(TAG, "onCreate: started.");
        setActionBarTitle(title);

        getIncoming();
    }

    private void setActionBarTitle(String title) {
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle(title);
        }
    }

    private void getIncoming(){
        if (getIntent().hasExtra("imgPhoto") && getIntent().hasExtra("itemView")){
            String tvTeam = getIntent().getStringExtra("imgPhoto");
            String tvFrom = getIntent().getStringExtra("itemView");

            setImage(tvTeam, tvFrom);
        }
    }

    private void setImage(String tvTeam, String tvFrom){
        ImageView team = findViewById(R.id.rv_team);
        Glide.with(this)
        .asBitmap()
        .load(tvTeam)
        .into(team);

        TextView id = findViewById(R.id.tv_item_team);
        id.setText(tvFrom);

        TextView from = findViewById(R.id.tv_item_from);
        from.setText(tvFrom);
    }
}